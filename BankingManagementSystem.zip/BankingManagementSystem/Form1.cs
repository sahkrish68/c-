﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankingManagementSystem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username = textBox1.Text;
            string password = textBox2.Text;

            string filePath = "D:\\krish\\BMS\\UserRecords.txt";

            string[] lines = System.IO.File.ReadAllLines(filePath);


            foreach (string line in lines)
            {
                string[] parts = line.Split(' ');
                if (parts.Length == 2 && parts[0] == username && parts[1] == password)
                {
                    MessageBox.Show("Login successful!");
                    return;
                }

            }


            MessageBox.Show("Invalid username or password. Please try again.");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string username = textBox1.Text.Trim();

            if (string.IsNullOrEmpty(username))
            {

                MessageBox.Show("Username cannot be empty.");

                return;
            }
        }
    }
}
    

