﻿using System;
using System.Data;

namespace BloodManagementSystem.UI
{
    internal class donorDAL
    {
        internal DataTable Select()
        {
            throw new NotImplementedException();
        }
    }
}