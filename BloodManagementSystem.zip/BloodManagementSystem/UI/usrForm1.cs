﻿using BloodBankManagementSystem.DAL;
using System;

namespace BloodManagementSystem
{
    internal class usrForm
    {
        internal void Show()
        {
            usrForm user = new usrForm();
        }
    }
}