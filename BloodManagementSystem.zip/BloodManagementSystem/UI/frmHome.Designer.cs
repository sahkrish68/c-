﻿namespace BloodManagementSystem
{
    partial class frmHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmHome));
            this.menuStrip_top = new System.Windows.Forms.MenuStrip();
            this.userToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.donerToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.userToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.donerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel_footer = new System.Windows.Forms.Panel();
            this.label_Devtitle = new System.Windows.Forms.Label();
            this.label_name = new System.Windows.Forms.Label();
            this.br = new System.Windows.Forms.Panel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.lblName = new System.Windows.Forms.Label();
            this.lblopositivecount = new System.Windows.Forms.Label();
            this.Opositive = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.labelApositive = new System.Windows.Forms.Label();
            this.labelApossitive = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
            this.label4 = new System.Windows.Forms.Label();
            this.label0nagative = new System.Windows.Forms.Label();
            this.lblonagative = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
            this.label7 = new System.Windows.Forms.Label();
            this.labelAnegative = new System.Windows.Forms.Label();
            this.Anagative = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.flowLayoutPanel5 = new System.Windows.Forms.FlowLayoutPanel();
            this.label10 = new System.Windows.Forms.Label();
            this.label11ABnagative = new System.Windows.Forms.Label();
            this.labelABnagative = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.flowLayoutPanel6 = new System.Windows.Forms.FlowLayoutPanel();
            this.label13 = new System.Windows.Forms.Label();
            this.labebenagative = new System.Windows.Forms.Label();
            this.labelbnagative = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.flowLayoutPanel7 = new System.Windows.Forms.FlowLayoutPanel();
            this.label16 = new System.Windows.Forms.Label();
            this.labelabpositibe = new System.Windows.Forms.Label();
            this.labelABpositive = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.flowLayoutPanel8 = new System.Windows.Forms.FlowLayoutPanel();
            this.label19 = new System.Windows.Forms.Label();
            this.labelbpositibe = new System.Windows.Forms.Label();
            this.labelBpositive = new System.Windows.Forms.Label();
            this.labelSearch = new System.Windows.Forms.Label();
            this.textSearch = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.DGVdoners = new System.Windows.Forms.DataGridView();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.menuStrip_top.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.panel_footer.SuspendLayout();
            this.br.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGVdoners)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip_top
            // 
            this.menuStrip_top.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip_top.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip_top.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.userToolStripMenuItem1,
            this.donerToolStripMenuItem1});
            this.menuStrip_top.Location = new System.Drawing.Point(0, 0);
            this.menuStrip_top.Name = "menuStrip_top";
            this.menuStrip_top.Padding = new System.Windows.Forms.Padding(8, 10, 0, 10);
            this.menuStrip_top.Size = new System.Drawing.Size(1435, 47);
            this.menuStrip_top.TabIndex = 0;
            this.menuStrip_top.Text = "menuStrip1";
            // 
            // userToolStripMenuItem1
            // 
            this.userToolStripMenuItem1.Name = "userToolStripMenuItem1";
            this.userToolStripMenuItem1.Size = new System.Drawing.Size(59, 27);
            this.userToolStripMenuItem1.Text = "User";
            this.userToolStripMenuItem1.Click += new System.EventHandler(this.userToolStripMenuItem1_Click);
            // 
            // donerToolStripMenuItem1
            // 
            this.donerToolStripMenuItem1.Name = "donerToolStripMenuItem1";
            this.donerToolStripMenuItem1.Size = new System.Drawing.Size(73, 27);
            this.donerToolStripMenuItem1.Text = "Doner";
            this.donerToolStripMenuItem1.Click += new System.EventHandler(this.donerToolStripMenuItem1_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.userToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(108, 28);
            // 
            // userToolStripMenuItem
            // 
            this.userToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.donerToolStripMenuItem});
            this.userToolStripMenuItem.Name = "userToolStripMenuItem";
            this.userToolStripMenuItem.Size = new System.Drawing.Size(107, 24);
            this.userToolStripMenuItem.Text = "User";
            // 
            // donerToolStripMenuItem
            // 
            this.donerToolStripMenuItem.Name = "donerToolStripMenuItem";
            this.donerToolStripMenuItem.Size = new System.Drawing.Size(133, 26);
            this.donerToolStripMenuItem.Text = "Doner";
            // 
            // panel_footer
            // 
            this.panel_footer.BackColor = System.Drawing.Color.White;
            this.panel_footer.Controls.Add(this.label_Devtitle);
            this.panel_footer.Controls.Add(this.label_name);
            this.panel_footer.Location = new System.Drawing.Point(0, 714);
            this.panel_footer.Name = "panel_footer";
            this.panel_footer.Size = new System.Drawing.Size(1559, 52);
            this.panel_footer.TabIndex = 2;
            // 
            // label_Devtitle
            // 
            this.label_Devtitle.AutoSize = true;
            this.label_Devtitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Devtitle.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label_Devtitle.Location = new System.Drawing.Point(1066, 13);
            this.label_Devtitle.Name = "label_Devtitle";
            this.label_Devtitle.Size = new System.Drawing.Size(344, 32);
            this.label_Devtitle.TabIndex = 1;
            this.label_Devtitle.Text = "Developd By - Krish Sah";
            // 
            // label_name
            // 
            this.label_name.AutoSize = true;
            this.label_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_name.ForeColor = System.Drawing.Color.Red;
            this.label_name.Location = new System.Drawing.Point(8, 14);
            this.label_name.Name = "label_name";
            this.label_name.Size = new System.Drawing.Size(434, 32);
            this.label_name.TabIndex = 0;
            this.label_name.Text = "Blood Bank Management System";
            // 
            // br
            // 
            this.br.BackColor = System.Drawing.SystemColors.Control;
            this.br.Controls.Add(this.flowLayoutPanel1);
            this.br.Controls.Add(this.lblName);
            this.br.Controls.Add(this.lblopositivecount);
            this.br.Controls.Add(this.Opositive);
            this.br.Location = new System.Drawing.Point(24, 161);
            this.br.Name = "br";
            this.br.Size = new System.Drawing.Size(237, 115);
            this.br.TabIndex = 3;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Location = new System.Drawing.Point(-37, -88);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(200, 100);
            this.flowLayoutPanel1.TabIndex = 3;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(161, 84);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(65, 25);
            this.lblName.TabIndex = 2;
            this.lblName.Text = "Doner";
            // 
            // lblopositivecount
            // 
            this.lblopositivecount.AutoSize = true;
            this.lblopositivecount.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblopositivecount.ForeColor = System.Drawing.Color.Red;
            this.lblopositivecount.Location = new System.Drawing.Point(143, 16);
            this.lblopositivecount.Name = "lblopositivecount";
            this.lblopositivecount.Size = new System.Drawing.Size(94, 51);
            this.lblopositivecount.TabIndex = 1;
            this.lblopositivecount.Text = "100";
            // 
            // Opositive
            // 
            this.Opositive.AutoSize = true;
            this.Opositive.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Opositive.ForeColor = System.Drawing.Color.Red;
            this.Opositive.Location = new System.Drawing.Point(3, 27);
            this.Opositive.Name = "Opositive";
            this.Opositive.Size = new System.Drawing.Size(114, 69);
            this.Opositive.TabIndex = 0;
            this.Opositive.Text = "O+";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Control;
            this.panel1.Controls.Add(this.flowLayoutPanel2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.labelApositive);
            this.panel1.Controls.Add(this.labelApossitive);
            this.panel1.Location = new System.Drawing.Point(24, 282);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(237, 110);
            this.panel1.TabIndex = 4;
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Location = new System.Drawing.Point(-37, -88);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(200, 100);
            this.flowLayoutPanel2.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(161, 84);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "Doner";
            // 
            // labelApositive
            // 
            this.labelApositive.AutoSize = true;
            this.labelApositive.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelApositive.ForeColor = System.Drawing.Color.Red;
            this.labelApositive.Location = new System.Drawing.Point(143, 16);
            this.labelApositive.Name = "labelApositive";
            this.labelApositive.Size = new System.Drawing.Size(94, 51);
            this.labelApositive.TabIndex = 1;
            this.labelApositive.Text = "100";
            // 
            // labelApossitive
            // 
            this.labelApossitive.AutoSize = true;
            this.labelApossitive.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelApossitive.ForeColor = System.Drawing.Color.Red;
            this.labelApossitive.Location = new System.Drawing.Point(3, 29);
            this.labelApossitive.Name = "labelApossitive";
            this.labelApossitive.Size = new System.Drawing.Size(107, 69);
            this.labelApossitive.TabIndex = 0;
            this.labelApossitive.Text = "A+";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Control;
            this.panel2.Controls.Add(this.flowLayoutPanel3);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label0nagative);
            this.panel2.Controls.Add(this.lblonagative);
            this.panel2.Location = new System.Drawing.Point(277, 161);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(237, 115);
            this.panel2.TabIndex = 4;
            // 
            // flowLayoutPanel3
            // 
            this.flowLayoutPanel3.Location = new System.Drawing.Point(-37, -88);
            this.flowLayoutPanel3.Name = "flowLayoutPanel3";
            this.flowLayoutPanel3.Size = new System.Drawing.Size(200, 100);
            this.flowLayoutPanel3.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(161, 84);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 25);
            this.label4.TabIndex = 2;
            this.label4.Text = "Doner";
            // 
            // label0nagative
            // 
            this.label0nagative.AutoSize = true;
            this.label0nagative.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label0nagative.ForeColor = System.Drawing.Color.Red;
            this.label0nagative.Location = new System.Drawing.Point(143, 16);
            this.label0nagative.Name = "label0nagative";
            this.label0nagative.Size = new System.Drawing.Size(94, 51);
            this.label0nagative.TabIndex = 1;
            this.label0nagative.Text = "100";
            // 
            // lblonagative
            // 
            this.lblonagative.AutoSize = true;
            this.lblonagative.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblonagative.ForeColor = System.Drawing.Color.Red;
            this.lblonagative.Location = new System.Drawing.Point(3, 29);
            this.lblonagative.Name = "lblonagative";
            this.lblonagative.Size = new System.Drawing.Size(99, 69);
            this.lblonagative.TabIndex = 0;
            this.lblonagative.Text = "O-";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.Control;
            this.panel3.Controls.Add(this.flowLayoutPanel4);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.labelAnegative);
            this.panel3.Controls.Add(this.Anagative);
            this.panel3.Location = new System.Drawing.Point(277, 282);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(237, 109);
            this.panel3.TabIndex = 4;
            // 
            // flowLayoutPanel4
            // 
            this.flowLayoutPanel4.Location = new System.Drawing.Point(-37, -88);
            this.flowLayoutPanel4.Name = "flowLayoutPanel4";
            this.flowLayoutPanel4.Size = new System.Drawing.Size(200, 100);
            this.flowLayoutPanel4.TabIndex = 3;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(161, 84);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 25);
            this.label7.TabIndex = 2;
            this.label7.Text = "Doner";
            // 
            // labelAnegative
            // 
            this.labelAnegative.AutoSize = true;
            this.labelAnegative.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAnegative.ForeColor = System.Drawing.Color.Red;
            this.labelAnegative.Location = new System.Drawing.Point(143, 16);
            this.labelAnegative.Name = "labelAnegative";
            this.labelAnegative.Size = new System.Drawing.Size(94, 51);
            this.labelAnegative.TabIndex = 1;
            this.labelAnegative.Text = "100";
            // 
            // Anagative
            // 
            this.Anagative.AutoSize = true;
            this.Anagative.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Anagative.ForeColor = System.Drawing.Color.Red;
            this.Anagative.Location = new System.Drawing.Point(3, 29);
            this.Anagative.Name = "Anagative";
            this.Anagative.Size = new System.Drawing.Size(92, 69);
            this.Anagative.TabIndex = 0;
            this.Anagative.Text = "A-";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.Control;
            this.panel4.Controls.Add(this.flowLayoutPanel5);
            this.panel4.Controls.Add(this.label10);
            this.panel4.Controls.Add(this.label11ABnagative);
            this.panel4.Controls.Add(this.labelABnagative);
            this.panel4.Location = new System.Drawing.Point(277, 519);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(237, 109);
            this.panel4.TabIndex = 6;
            // 
            // flowLayoutPanel5
            // 
            this.flowLayoutPanel5.Location = new System.Drawing.Point(-37, -88);
            this.flowLayoutPanel5.Name = "flowLayoutPanel5";
            this.flowLayoutPanel5.Size = new System.Drawing.Size(200, 100);
            this.flowLayoutPanel5.TabIndex = 3;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(161, 84);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 25);
            this.label10.TabIndex = 2;
            this.label10.Text = "Doner";
            // 
            // label11ABnagative
            // 
            this.label11ABnagative.AutoSize = true;
            this.label11ABnagative.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11ABnagative.ForeColor = System.Drawing.Color.Red;
            this.label11ABnagative.Location = new System.Drawing.Point(143, 16);
            this.label11ABnagative.Name = "label11ABnagative";
            this.label11ABnagative.Size = new System.Drawing.Size(94, 51);
            this.label11ABnagative.TabIndex = 1;
            this.label11ABnagative.Text = "100";
            // 
            // labelABnagative
            // 
            this.labelABnagative.AutoSize = true;
            this.labelABnagative.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelABnagative.ForeColor = System.Drawing.Color.Red;
            this.labelABnagative.Location = new System.Drawing.Point(3, 29);
            this.labelABnagative.Name = "labelABnagative";
            this.labelABnagative.Size = new System.Drawing.Size(133, 69);
            this.labelABnagative.TabIndex = 0;
            this.labelABnagative.Text = "AB-";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.Control;
            this.panel5.Controls.Add(this.flowLayoutPanel6);
            this.panel5.Controls.Add(this.label13);
            this.panel5.Controls.Add(this.labebenagative);
            this.panel5.Controls.Add(this.labelbnagative);
            this.panel5.Location = new System.Drawing.Point(277, 398);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(237, 115);
            this.panel5.TabIndex = 7;
            // 
            // flowLayoutPanel6
            // 
            this.flowLayoutPanel6.Location = new System.Drawing.Point(-37, -88);
            this.flowLayoutPanel6.Name = "flowLayoutPanel6";
            this.flowLayoutPanel6.Size = new System.Drawing.Size(200, 100);
            this.flowLayoutPanel6.TabIndex = 3;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(161, 84);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(65, 25);
            this.label13.TabIndex = 2;
            this.label13.Text = "Doner";
            // 
            // labebenagative
            // 
            this.labebenagative.AutoSize = true;
            this.labebenagative.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labebenagative.ForeColor = System.Drawing.Color.Red;
            this.labebenagative.Location = new System.Drawing.Point(143, 16);
            this.labebenagative.Name = "labebenagative";
            this.labebenagative.Size = new System.Drawing.Size(94, 51);
            this.labebenagative.TabIndex = 1;
            this.labebenagative.Text = "100";
            // 
            // labelbnagative
            // 
            this.labelbnagative.AutoSize = true;
            this.labelbnagative.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelbnagative.ForeColor = System.Drawing.Color.Red;
            this.labelbnagative.Location = new System.Drawing.Point(3, 29);
            this.labelbnagative.Name = "labelbnagative";
            this.labelbnagative.Size = new System.Drawing.Size(92, 69);
            this.labelbnagative.TabIndex = 0;
            this.labelbnagative.Text = "B-";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.Control;
            this.panel6.Controls.Add(this.flowLayoutPanel7);
            this.panel6.Controls.Add(this.label16);
            this.panel6.Controls.Add(this.labelabpositibe);
            this.panel6.Controls.Add(this.labelABpositive);
            this.panel6.Location = new System.Drawing.Point(24, 519);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(237, 109);
            this.panel6.TabIndex = 8;
            // 
            // flowLayoutPanel7
            // 
            this.flowLayoutPanel7.Location = new System.Drawing.Point(-37, -88);
            this.flowLayoutPanel7.Name = "flowLayoutPanel7";
            this.flowLayoutPanel7.Size = new System.Drawing.Size(200, 100);
            this.flowLayoutPanel7.TabIndex = 3;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(161, 84);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(65, 25);
            this.label16.TabIndex = 2;
            this.label16.Text = "Doner";
            // 
            // labelabpositibe
            // 
            this.labelabpositibe.AutoSize = true;
            this.labelabpositibe.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelabpositibe.ForeColor = System.Drawing.Color.Red;
            this.labelabpositibe.Location = new System.Drawing.Point(143, 16);
            this.labelabpositibe.Name = "labelabpositibe";
            this.labelabpositibe.Size = new System.Drawing.Size(94, 51);
            this.labelabpositibe.TabIndex = 1;
            this.labelabpositibe.Text = "100";
            // 
            // labelABpositive
            // 
            this.labelABpositive.AutoSize = true;
            this.labelABpositive.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelABpositive.ForeColor = System.Drawing.Color.Red;
            this.labelABpositive.Location = new System.Drawing.Point(3, 29);
            this.labelABpositive.Name = "labelABpositive";
            this.labelABpositive.Size = new System.Drawing.Size(148, 69);
            this.labelABpositive.TabIndex = 0;
            this.labelABpositive.Text = "AB+";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.Control;
            this.panel7.Controls.Add(this.flowLayoutPanel8);
            this.panel7.Controls.Add(this.label19);
            this.panel7.Controls.Add(this.labelbpositibe);
            this.panel7.Controls.Add(this.labelBpositive);
            this.panel7.Location = new System.Drawing.Point(24, 398);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(237, 115);
            this.panel7.TabIndex = 5;
            // 
            // flowLayoutPanel8
            // 
            this.flowLayoutPanel8.Location = new System.Drawing.Point(-37, -88);
            this.flowLayoutPanel8.Name = "flowLayoutPanel8";
            this.flowLayoutPanel8.Size = new System.Drawing.Size(200, 100);
            this.flowLayoutPanel8.TabIndex = 3;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(161, 84);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(65, 25);
            this.label19.TabIndex = 2;
            this.label19.Text = "Doner";
            // 
            // labelbpositibe
            // 
            this.labelbpositibe.AutoSize = true;
            this.labelbpositibe.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelbpositibe.ForeColor = System.Drawing.Color.Red;
            this.labelbpositibe.Location = new System.Drawing.Point(143, 16);
            this.labelbpositibe.Name = "labelbpositibe";
            this.labelbpositibe.Size = new System.Drawing.Size(94, 51);
            this.labelbpositibe.TabIndex = 1;
            this.labelbpositibe.Text = "100";
            // 
            // labelBpositive
            // 
            this.labelBpositive.AutoSize = true;
            this.labelBpositive.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBpositive.ForeColor = System.Drawing.Color.Red;
            this.labelBpositive.Location = new System.Drawing.Point(3, 29);
            this.labelBpositive.Name = "labelBpositive";
            this.labelBpositive.Size = new System.Drawing.Size(107, 69);
            this.labelBpositive.TabIndex = 0;
            this.labelBpositive.Text = "B+";
            // 
            // labelSearch
            // 
            this.labelSearch.AutoSize = true;
            this.labelSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSearch.Location = new System.Drawing.Point(680, 93);
            this.labelSearch.Name = "labelSearch";
            this.labelSearch.Size = new System.Drawing.Size(145, 25);
            this.labelSearch.TabIndex = 10;
            this.labelSearch.Text = "Search Doner";
            // 
            // textSearch
            // 
            this.textSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textSearch.Location = new System.Drawing.Point(685, 125);
            this.textSearch.Name = "textSearch";
            this.textSearch.Size = new System.Drawing.Size(583, 30);
            this.textSearch.TabIndex = 11;
            this.textSearch.TextChanged += new System.EventHandler(this.textSearch_TextChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::BloodManagementSystem.Properties.Resources.cross;
            this.pictureBox1.Location = new System.Drawing.Point(1369, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(54, 34);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // DGVdoners
            // 
            this.DGVdoners.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVdoners.Location = new System.Drawing.Point(578, 161);
            this.DGVdoners.Name = "DGVdoners";
            this.DGVdoners.RowHeadersWidth = 51;
            this.DGVdoners.RowTemplate.Height = 24;
            this.DGVdoners.Size = new System.Drawing.Size(804, 537);
            this.DGVdoners.TabIndex = 9;
            this.DGVdoners.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVdoners_CellContentClick);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(24, 60);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(93, 85);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 13;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(123, 87);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(163, 29);
            this.label3.TabIndex = 15;
            this.label3.Text = "Management";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(123, 116);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(98, 29);
            this.label5.TabIndex = 16;
            this.label5.Text = "System";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(123, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 29);
            this.label2.TabIndex = 14;
            this.label2.Text = "Blood";
            // 
            // frmHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(1435, 768);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.textSearch);
            this.Controls.Add(this.labelSearch);
            this.Controls.Add(this.DGVdoners);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.br);
            this.Controls.Add(this.panel_footer);
            this.Controls.Add(this.menuStrip_top);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MainMenuStrip = this.menuStrip_top;
            this.Name = "frmHome";
            this.Text = " ";
            this.Load += new System.EventHandler(this.frmHome_Load);
            this.menuStrip_top.ResumeLayout(false);
            this.menuStrip_top.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.panel_footer.ResumeLayout(false);
            this.panel_footer.PerformLayout();
            this.br.ResumeLayout(false);
            this.br.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGVdoners)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip_top;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem userToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem donerToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem userToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem donerToolStripMenuItem;
        private System.Windows.Forms.Panel panel_footer;
        private System.Windows.Forms.Label label_name;
        private System.Windows.Forms.Label label_Devtitle;
        private System.Windows.Forms.Panel br;
        private System.Windows.Forms.Label lblopositivecount;
        private System.Windows.Forms.Label Opositive;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelApositive;
        private System.Windows.Forms.Label labelApossitive;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label0nagative;
        private System.Windows.Forms.Label lblonagative;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label labelAnegative;
        private System.Windows.Forms.Label Anagative;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11ABnagative;
        private System.Windows.Forms.Label labelABnagative;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel6;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label labebenagative;
        private System.Windows.Forms.Label labelbnagative;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel7;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label labelabpositibe;
        private System.Windows.Forms.Label labelABpositive;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel8;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label labelbpositibe;
        private System.Windows.Forms.Label labelBpositive;
        private System.Windows.Forms.Label labelSearch;
        private System.Windows.Forms.TextBox textSearch;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridView DGVdoners;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
    }
}

